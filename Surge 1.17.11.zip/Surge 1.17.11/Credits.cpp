/*                      Credits:
	HUGE CREDIT TO Doomnet FOR MAKING THE INJECTOR!!!!!!!!!!!!
	Credit to Kow#1833 for making the Mineplex fly and the lowhop.
	Credit to Packet for helping with many things including making the freecam, 
	and the freecam and timer to scaffold. Plus, he tought me many things related to code.
	Credit to Old Greggo for helping with tracers and damage fly.
	Credit to Intop for helping with stuff.
	Credit to the origional horion owners and devs for the open source git hub.
	*/