#pragma once

#include "../ScriptManager.h"

class GameFunctions {
public:
	DECL_FUN(getClient);
	DECL_FUN(getLocalPlayer);
	DECL_FUN(getLevel);
};
